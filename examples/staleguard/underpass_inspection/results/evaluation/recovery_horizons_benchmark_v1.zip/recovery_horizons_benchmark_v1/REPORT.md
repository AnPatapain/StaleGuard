# Underpass 2-policy evaluation benchmark

Implemented 2 policies on 100 frozen evaluation scenarios. The UAV flies North toward a bridge; its approved command dives underneath to inspect and swerves East around a pier. Every recovery instead abandons inspection and uses the same independent Eastward sideways maneuver. This journal contains 2600/2600 actual PyBullet executions. The two new policies are physically executed; original policy outcomes are not rerun. Prediction readiness, false-safe decisions and abandoned inspections are reported separately. The scenario is the independent experimental unit; simulation results do not establish real-world safety.

All policies use the same physical scenario, PID and eight-second horizon after approval. Safety is monitored at 1,000 Hz from reset, including before intervention and after a violation. Unsafe inspection dwell is never counted as safe completion. Dispatch delays are unknown to the policy until the event occurs. No offline deadline or other policy outcome is supplied to a policy.

**Complete paired matrix.**

| Policy | Flights | Unsafe | Safe inspection | Recovery | Early recovery | Ready false-safe decisions |
|---|---:|---:|---:|---:|---:|---:|
| staleguard_recovery_aware | 1300 | 49 | 744 | 511 | 486 | 37 |
| staleguard_dual_horizon | 1300 | 48 | 744 | 512 | 486 | 37 |

Early means recovery starts strictly before the scheduled dispatch, including Always Recover at approval for positive delays. At D=0 Always Recover still cancels immediately. Fixed EarlyRecovery uses 0.20 s with >= equality. Climb is never selected. A rejected command can still lead to an unsafe flight when sideways recovery starts too late.

| Policy versus No Recovery | Unsafe prevented | Unsafe introduced | Safe inspections preserved | Safe inspections lost |
|---|---:|---:|---:|---:|

**Reduced protocol:** 100 scenarios uniformly sampled without replacement from 865 accepted, using RNG seed 20261108. The full reduced grid has 13 delays: 0, 0.04, 0.08, 0.12, 0.16, 0.20, 0.40, 0.60, 0.80, 1.00, 1.20, 1.60, 2.00 s. Gaps range from 0.04 to 0.40 s. Observed expiration thresholds are first tested unsafe points, not exact deadlines. All ten selected delays through 1 s are prediction-grid points, so this reduced design does not test between-grid admissions within 1 s. Rates average the selected points equally; they do not assume a uniform continuous dispatch-delay distribution.

The physical grid covers 0–2.00 s; the predictor still tests only its original 19 delays through 1.00 s. These windows are subsets of one benchmark. With no predicted expiration, the unchanged StaleGuard gate permits dispatch even beyond 1 s; this is not a safety certificate for those delays. A ready finite TTL still rejects at/after expiry, and unavailable predictions still permit dispatch.

The fixed eight-second horizon is unchanged. Missing inspection dwell means incomplete by that deadline, not proof it could never complete later. Truncated maneuver profiles are recorded separately.

Analysis subset: **full**

| Policy | Flights | Unsafe | Safe inspections | Unsafe rate, scenario mean [95% CI] |
|---|---:|---:|---:|---|
| staleguard_recovery_aware | 1300 | 49 | 744 | 0.038 [0.024–0.054] |
| staleguard_dual_horizon | 1300 | 48 | 744 | 0.037 [0.023–0.053] |

Analysis subset: **within_prediction_horizon**

| Policy | Flights | Unsafe | Safe inspections | Unsafe rate, scenario mean [95% CI] |
|---|---:|---:|---:|---|
| staleguard_recovery_aware | 1000 | 12 | 736 | 0.012 [0.005–0.020] |
| staleguard_dual_horizon | 1000 | 11 | 736 | 0.011 [0.005–0.019] |

Analysis subset: **beyond_prediction_horizon**

| Policy | Flights | Unsafe | Safe inspections | Unsafe rate, scenario mean [95% CI] |
|---|---:|---:|---:|---|
| staleguard_recovery_aware | 300 | 37 | 8 | 0.123 [0.070–0.187] |
| staleguard_dual_horizon | 300 | 37 | 8 | 0.123 [0.070–0.187] |

95% percentile bootstrap intervals resample whole scenarios (2,000 resamples, fixed seed 2027). Complete scenario grids contribute; fewer than two complete scenarios gives no interval. Paired net safety/completion differences use the same scenario resamples and are in metrics.json; correlated delay trials are never treated as independent scenarios.

**Exploratory extension:** these scenarios were examined in the earlier seven-policy study. New policies were developed/profiler-tested only on development scenarios, but this is not a fresh held-out superiority test. Existing flights were not rerun. New policy forecasts are independently computed/timed; all online waiting, both continuations, completion checks and boundary extraction count toward their atomic readiness.

Prediction availability means the approval-time forecast has finished by the scheduled dispatch time (including equality). For EarlyRecovery, the denominator also includes commands already canceled by an earlier recovery.

| Policy | Available by scheduled dispatch | Availability rate |
|---|---:|---:|
| StaleGuard RecoveryAware | 856/1300 cases | 65.8% |
| StaleGuard DualHorizon | 862/1300 cases | 66.3% |

The original StaleGuard pair shares forecasts/runtime. Each new policy has an independently timed run of the same three-profile predictor; no cross-policy computation cache advances readiness. For the root predictor summary (scope_policy in metrics.json), a second measure is readiness by predicted command expiration: **69/75 scenario forecasts (92.0%)** finish by that time; 6/75 finish later. Scenarios with no predicted expiration within the prediction grid are excluded only from this second denominator (25 here). These rates use measured warmed computation times replayed on the simulation clock; they do not describe cold-start availability. Availability alone does not establish prediction correctness or safe recovery.

An unavailable forecast permits dispatch under the established policy rule. StaleGuard RecoveryAware: 444 cases without a forecast by dispatch, 8 unsafe dispatches; StaleGuard DualHorizon: 438 cases without a forecast by dispatch, 7 unsafe dispatches. These counts overlap across variants and must not be added together.

The original StaleGuard pair shares one measured approval forecast per scenario and runtime. Each new policy independently computes/times the shared three-profile predictor. The shared 100 Hz lightweight model preserves PID memory, predicts nominal waiting and then anchors the same dive to each predicted dispatch state. A swept 3D Euclidean box/body checker applies the unchanged clearance threshold. The fixed prediction grid follows Geofence (19 candidate delays); actual dispatch uses 13 delays. Expiration is the first predicted unsafe grid point; an all-safe grid has unobserved expiration.

Approval forecast runtime: 100 scenario samples, median 0.15484541753539816 s, p95 0.19496301608160138 s. Finite comparable TTL errors: 75; median absolute error 0.020000000000000004 s. Unobserved boundaries are excluded from scalar TTL errors, not from flight outcomes. First-forecast and subsequent timing, startup warmup and per-scenario forecasts are stored separately.

The TTL admission rule has 70 false-safe and 2 false-reject scenario/delay labels. Direct model labels at sampled prediction-grid points have 3 false-safe and 2 false-reject labels. The distinction exposes errors between coarse prediction-grid points as well as dynamic-model mismatch. 6 forecasts finish after their predicted expiry; unavailable dispatches remain separate from ready false-safe decisions.

Computation is measured offline, then its duration is replayed on the physical control clock, matching Geofence. Nominal flight continues until the result becomes actionable. An unavailable approval forecast permits dispatch and cannot cancel an already started command later. EarlyRecovery waits for both readiness and expiration; a late result acts at its actual ready control step while still pending, never retroactively. Use-Time Recheck performs one dispatch-state rollout and acts strictly after measured computation on the control grid; that movement during checking can change its eventual outcome.

Seeds with negative physical recovery gaps and unobserved command expiration remain in the cohort. Scenario is the independent experimental unit; aggregate flight counts are repeated-case descriptions. Per-scenario results, all cell outcomes and paired EarlyRecovery comparisons are in the CSVs and metrics.json. The [technical appendix](TECHNICAL_APPENDIX.md) documents policy rules, source equivalence, tests, timing limitations and reproduction.

New policy predictor runtime (warmed, independently computed per policy/scenario):

| Policy | Forecasts | Median ms | p95 ms |
|---|---:|---:|---:|
| staleguard_recovery_aware | 100 | 154.8 | 195.0 |
| staleguard_dual_horizon | 100 | 153.4 | 192.0 |

RecoveryAware proactively uses the earlier of command expiry and the last safe recovery-prefix grid point. DualHorizon also considers completion expiry. A late prediction does not retroactively act. A missed recovery prefix does not invalidate an otherwise safe command; known-expired commands use the existing recovery as best-effort. Completion-only abandonment requires verified recovery. All-safe grids are censored; no horizon-end rejection is invented.

Whole-flight failure decomposition and command/completion/recovery prediction labels are in metrics.json. Recovery-label comparisons include only actual starts that coincide with predicted grid points. The root predictor summary refers to the policy named by predictor.scope_policy.
