# Inspection-Descent — PGFPlots-ready CSVs

Source: uploaded independent_evaluation_20_319 archive, `main_result/executions.jsonl`.
Journal SHA-256, `per_delay.csv` and `aggregate.csv` verified against `core_manifest.json`.

- 276 feasible scenarios (seeds 20–319 attempted, 24 infeasible not evaluated).
- 11 dispatch delays, 0 to 1 s, step 0.1 s.
- Six original policies: No Recovery, Always Recover, Fixed TTL (0.30 s), FBS, Use-Time Recheck, and dispatch-only StaleGuard.
- 276 scenario evaluations per delay/policy; 3036 evaluations per policy; 18,216 policy evaluation records total. Some records are verified reused trajectories rather than independently simulated flights.
- The two combined files each have `delay_s` followed by the same six policy columns as their Geofence equivalents. Rates are percentage points (0..100), not 0..1 fractions.
- `outcome[1]` means unsafe execution; `outcome[3]` means **safe** mission completion. Inspection completion without safety is NOT counted as safe completion.
- Each individual policy CSV contains both percentage curves and raw counts.

**No StaleGuard-EarlyRecovery or Fixed-EarlyRecovery Inspection series** exists in this archive. Do not invent these or reuse Geofence results for the Inspection panels.

PGFPlots snippet:
```
\addplot+[blue,thick] table[col sep=comma,x=delay_s,y=staleguard_dispatch_recovery]
    {figures/figure2/inspection_unsafe_rates.csv};
```

Columns in combined files:
`delay_s,no_recovery,always_recover,fixed_ttl,fbs,use_time_recheck,staleguard_dispatch_recovery`

Totals independently verified:
- no_recovery: unsafe 1841/3036; safe completion 930/3036
- always_recover: unsafe 0/3036; safe completion 276/3036
- fixed_ttl: unsafe 139/3036; safe completion 819/3036
- fbs: unsafe 1841/3036; safe completion 930/3036
- use_time_recheck: unsafe 63/3036; safe completion 864/3036
- staleguard_dispatch_recovery: unsafe 22/3036; safe completion 917/3036
