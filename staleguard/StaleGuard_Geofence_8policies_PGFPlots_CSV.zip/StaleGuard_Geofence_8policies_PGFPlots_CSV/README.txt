Geofence Turn — 8-policy PGFPlots-ready CSV update

Updated combined CSVs each contain 23 dispatch delays (seconds) and percentages (0..100), with column fixed_early_recovery appended at the end. Existing 7 policy columns are preserved byte-for-byte as numerical strings.

Files:
- geofence_unsafe_rates.csv: y=fixed_early_recovery for unsafe rate
- geofence_safe_completion_rates.csv: y=fixed_early_recovery for safe-completion rate
- fixed_early_recovery.csv: individual source-based rates and counts

Source: fixed_early_benchmark(1).zip/fixed_early_benchmark/executions.jsonl, policy=fixed_early_recovery (timeout=0.20s, proactive pre-dispatch recovery). Independently checked all 6900 records and 23 per-delay slices against metrics.json. Total unsafe 315/6900; safe completions 1692/6900.

Use with PGFPlots:
  table[col sep=comma,x=delay_s,y=fixed_early_recovery]{figures/figure2/geofence_unsafe_rates.csv};
  table[col sep=comma,x=delay_s,y=fixed_early_recovery]{figures/figure2/geofence_safe_completion_rates.csv};

Keep fixed_ttl as a separate column: it is the dispatch-only 0.40s threshold baseline from the original six-policy benchmark, not Fixed-EarlyRecovery.
